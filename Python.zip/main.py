import random

print("Hello World")
name = input("What is your name? " )
if name != "Ronnie" and name != "ronnie":
  print("You are not Ronnie.")
if name == "Ronnie" or name == "ronnie": 
    print("Welcome, " + name)
Age = input("How old are you? ")
if Age != "atleast 2":
  print("You are not Ronnie")
if Age == "atleast 2":
    print("Welcome Ronnie. You are " + Age + " years old")
    print("We have idenified you as Ronnie. Welcome.")
Passcode = input("What is your passcode? ")
if Passcode != "1234":
  print("Incorrect passcode. Please try again.")
if Passcode == "1234":
  print("Correct passcode. Welcome Ronnie.")
  roll = input("Would you like to roll a dice? ")
  if roll == "yes" or roll == "Yes":
    import random
  roll = "yes"
  while roll == "yes" or roll=="Yes" or roll=="Y" or roll=="y":
      print("Rolling the dice...")
      print("The value is...") 
      dice1=random.randint(1,6)
      print(dice1)
      dice2=random.randint(1,6)
      print(dice2)
      print("Total: ",dice1+dice2)
      roll = input("Roll the dice again? ")
      while roll == "no" or roll == "n" or roll == "N" or roll == "No":
        roll = input("What would you like to do? ")
      if roll == "Nothing":
        print("Okay, have a nice day!") 
      if roll == "calculator" or roll == "Calculator" or roll == "calc" or roll == "Calc":
        print("Welcome to the calculator")
        print("Please select an operation")
        print("1. Add")
        print("2. Subtract")
        print("3. Multiply")
        print("4. Divide")
        choice = input("Enter choice (1/2/3/4): ")
        if choice == "1":
          num1 = int(input("Enter first number: "))
          num2 = int(input("Enter second number: "))
          print(num1, "+", num2, "=", num1 + num2) 
          choice = input("would you like to do another calculation?")
        if choice == "2":
          num1 = int(input("Enter first number: "))
          num2 = int(input("Enter second number: "))
          print(num1, "-", num2, "=", num1 - num2)
          choice = input("would you like to do another calculation?")
        if choice == "3":
          num1 = int(input("Enter first number: "))
          num2 = int(input("Enter second number: "))
          print(num1, "*", num2, "=", num1 * num2)
          choice = input("would you like to do another calculation?")
        if choice == "4":
          num1 = int(input("Enter first number: "))
          num2 = int(input("Enter second number: "))
          print(num1, "/", num2, "=", num1 / num2)
          choice = input("would you like to do another calculation?")